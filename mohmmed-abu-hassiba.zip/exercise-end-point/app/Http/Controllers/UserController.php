<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\User_exerces;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    //
    public function regesterMyExercises(Request $request)
    {
        $validation = Validator::make($request->all(),[
            'name' => 'required|string',
            'user_id' => 'required|numeric',
            'hours' => 'numeric|nullable',
            'mins' => 'numeric|nullable| lt:60',
        ]);

        if($validation->fails()){

            $errors = $validation->errors();

            $res = array(
                'status' 	=> 'error',
                'code' 		=> 231,
                'message' 	=> $errors->first()
            );
        }else{
            $userExerces = new User_exerces();
            $userExerces->user_id = $request->user_id;
            $userExerces->name = $request->name;
            $userExerces->hours = $request->hours;
            $userExerces->mins = $request->mins;

            $userExerces->save();

            if($userExerces->id){
                $message = "register exercises done";

                $res = array(
                    'status' 	=> 'done',
                    'code' 		=> 200,
                    'message' 	=> $message,
                );
            }else{

                $message = "error in register exercises";

                $res = array(
                    'status' => 'error',
                    'code' 	=> 400,
                    'message' => $message
                );
            }
        }
        return response()->json($res);
    }

    public function myDaysExercises(Request $request)
    {
        $month = Carbon::now()->firstOfMonth();

        $user = $this->checkToken($request);

        if($user != NULL){

            $userExerces = User_exerces::where('user_id',$user->id)->where('created_at','>=',$month)->get();

            $daysNumber = $userExerces->groupBy('created_at')->all();

            $daysNumber = collect($daysNumber);

            $res = array(
                'status' => 'done',
                'code' 	=> 200,
                'daysNumber' => $daysNumber->count()
            );
        }else{
            $message = "error this user not found";

            $res = array(
                'status' => 'error',
                'code' 	=> 401,
                'message' => $message
            );
        }

        return response()->json($res);
    }

    public function myHighestMonth(Request $request)
    {
        $user = $this->checkToken($request);

        $year = Carbon::now()->firstOfYear();

        if($user != NULL){

            $userExerces = User_exerces::where('user_id',$user->id)->where('created_at','>=',$year)->get();

            $HighestMonth = $userExerces->groupBy(function ($item,$key){
                return date('m',strtotime($item['created_at']));
            })->all();

            $HighestMonth = collect($HighestMonth);

            $max = $HighestMonth->max()->first();

            $resulte = date('m',strtotime($max->created_at)); 

            $res = array(
                'status' => 'done',
                'code' 	=> 200,
                'HighestMonth' => $resulte,
                'countOfDays' => $HighestMonth->max()->count()
            );
        }else{
            $message = "error this user not found";

            $res = array(
                'status' => 'error',
                'code' 	=> 401,
                'message' => $message
            );
        }

         return response()->json($res);

    }



    public function checkToken(Request $request)
    {
        if(!empty($request->header('Authorization'))) {
            $api_token = str_replace("Bearer ", "", $request->header('Authorization'));
            $user = User::where('api_token',$api_token)->first();
        }else{
            $user = NULL;
        }
        return $user;
    }

}
